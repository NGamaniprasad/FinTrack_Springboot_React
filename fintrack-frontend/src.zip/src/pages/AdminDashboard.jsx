import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";

import { getAdminDashboard } from "../services/api";

import "./AdminDashboard.css";

const AdminDashboard = () => {

    const navigate = useNavigate();

    const [dashboard, setDashboard] = useState(null);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState("");

    useEffect(() => {

        const token = localStorage.getItem("token");
        const role = localStorage.getItem("role");

        // Check admin login
        if (!token || role !== "ADMIN") {
            navigate("/admin/login");
            return;
        }

        const loadDashboard = async () => {

            try {

                const data = await getAdminDashboard();

                console.log("ADMIN DASHBOARD:", data);

                setDashboard(data);

            } catch (err) {

                console.error("ADMIN DASHBOARD ERROR:", err);

                setError(
                    err.message || "Unable to load admin dashboard"
                );

            } finally {

                setLoading(false);
            }
        };

        loadDashboard();

    }, [navigate]);


    const handleLogout = () => {

        localStorage.removeItem("token");
        localStorage.removeItem("role");
        localStorage.removeItem("userId");
        localStorage.removeItem("fullName");
        localStorage.removeItem("email");

        navigate("/admin/login");
    };


    if (loading) {

        return (
            <div className="admin-dashboard-page">

                <div className="admin-dashboard-container">

                    <h2>
                        Loading Admin Dashboard...
                    </h2>

                </div>

            </div>
        );
    }


    if (error) {

        return (
            <div className="admin-dashboard-page">

                <div className="admin-dashboard-container">

                    <div className="admin-error">
                        {error}
                    </div>

                </div>

            </div>
        );
    }


    return (
        <div className="admin-dashboard-page">

            <div className="admin-dashboard-container">

                {/* HEADER */}

                <div className="admin-dashboard-header">

                    <div>

                        <span className="admin-label">
                            FINTRACK ADMIN
                        </span>

                        <h1>
                            Admin Dashboard
                        </h1>

                        <p>
                            Welcome, {localStorage.getItem("fullName")}
                        </p>

                    </div>

                    <button
                        className="admin-logout-button"
                        onClick={handleLogout}
                    >
                        Logout
                    </button>

                </div>


                {/* STATISTICS */}

                <div className="admin-stat-grid">


                    <div className="admin-stat-card">

                        <span>
                            Total Users
                        </span>

                        <strong>
                            {dashboard?.totalUsers ?? 0}
                        </strong>

                    </div>


                    <div className="admin-stat-card">

                        <span>
                            Active Users
                        </span>

                        <strong>
                            {dashboard?.activeUsers ?? 0}
                        </strong>

                    </div>


                    <div className="admin-stat-card">

                        <span>
                            Inactive Users
                        </span>

                        <strong>
                            {dashboard?.inactiveUsers ?? 0}
                        </strong>

                    </div>


                    <div className="admin-stat-card">

                        <span>
                            Categories
                        </span>

                        <strong>
                            {dashboard?.totalCategories ?? 0}
                        </strong>

                    </div>


                    <div className="admin-stat-card">

                        <span>
                            Budgets
                        </span>

                        <strong>
                            {dashboard?.totalBudgets ?? 0}
                        </strong>

                    </div>


                    <div className="admin-stat-card">

                        <span>
                            Income Records
                        </span>

                        <strong>
                            {dashboard?.totalIncomes ?? 0}
                        </strong>

                    </div>


                    <div className="admin-stat-card">

                        <span>
                            Expense Records
                        </span>

                        <strong>
                            {dashboard?.totalExpenses ?? 0}
                        </strong>

                    </div>

                </div>


                {/* MANAGEMENT */}

                <div className="admin-management">

                    <h2>
                        Management
                    </h2>

                    <div className="admin-management-grid">


                        <button
                            onClick={() =>
                                navigate("/admin/users")
                            }
                            className="admin-management-card"
                        >

                            <h3>
                                User Management
                            </h3>

                            <p>
                                View, activate and deactivate users.
                            </p>

                        </button>


                        <button
                            onClick={() =>
                                navigate("/admin/categories")
                            }
                            className="admin-management-card"
                        >

                            <h3>
                                Category Management
                            </h3>

                            <p>
                                Manage financial categories.
                            </p>

                        </button>


                        <button
                            onClick={() =>
                                navigate("/admin/budgets")
                            }
                            className="admin-management-card"
                        >

                            <h3>
                                Budget Management
                            </h3>

                            <p>
                                Monitor and manage budgets.
                            </p>

                        </button>

                    </div>

                </div>

            </div>

        </div>
    );
};

export default AdminDashboard;