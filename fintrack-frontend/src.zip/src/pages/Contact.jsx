import { useState } from "react";
import "./Contact.css";

const Contact = () => {

    const [submitted, setSubmitted] = useState(false);

    const handleSubmit = (e) => {

        e.preventDefault();

        setSubmitted(true);

        e.target.reset();
    };

    return (
        <main className="contact-page">

            <section className="contact-header">

                <h1>Contact Us</h1>

                <p>
                    Have a question or feedback?
                    Send us a message.
                </p>

            </section>

            <section className="contact-container">

                <div className="contact-info">

                    <h2>Get in touch</h2>

                    <p>
                        We would love to hear your feedback
                        and suggestions about FinTrack.
                    </p>

                    <div className="contact-item">
                        <strong>Email</strong>
                        <span>support@fintrack.com</span>
                    </div>

                    <div className="contact-item">
                        <strong>Support</strong>
                        <span>Monday - Friday</span>
                    </div>

                </div>

                <form
                    className="contact-form"
                    onSubmit={handleSubmit}
                >

                    <label>Name</label>

                    <input
                        type="text"
                        placeholder="Enter your name"
                        required
                    />

                    <label>Email</label>

                    <input
                        type="email"
                        placeholder="Enter your email"
                        required
                    />

                    <label>Message</label>

                    <textarea
                        rows="6"
                        placeholder="Write your message"
                        required
                    />

                    <button type="submit">
                        Send Message
                    </button>

                    {submitted && (
                        <p className="contact-success">
                            Thank you! Your message has been received.
                        </p>
                    )}

                </form>

            </section>

        </main>
    );
};

export default Contact;