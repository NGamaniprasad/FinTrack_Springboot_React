import { useEffect, useState } from "react";

import {
    getDashboard
} from "../services/api";

import "./Dashboard.css";


const Dashboard = () => {

    const [dashboard, setDashboard] =
        useState(null);

    const [loading, setLoading] =
        useState(true);

    const [error, setError] =
        useState("");


    /* =================================================
       LOAD DASHBOARD
    ================================================= */

    useEffect(() => {

        const loadDashboard = async () => {

            try {

                const data =
                    await getDashboard();


                console.log(
                    "DASHBOARD DATA:",
                    data
                );


                setDashboard(data);

            } catch (err) {

                console.error(
                    "GET DASHBOARD ERROR:",
                    err
                );


                setError(
                    err.message ||
                    "Unable to load dashboard"
                );

            } finally {

                setLoading(false);
            }
        };


        loadDashboard();

    }, []);


    /* =================================================
       LOADING
    ================================================= */

    if (loading) {

        return (

            <main className="dashboard-page">

                <div className="dashboard-container">

                    <div className="dashboard-message">

                        Loading your dashboard...

                    </div>

                </div>

            </main>
        );
    }


    /* =================================================
       ERROR
    ================================================= */

    if (error) {

        return (

            <main className="dashboard-page">

                <div className="dashboard-container">

                    <div className="dashboard-error">

                        {error}

                    </div>

                </div>

            </main>
        );
    }


    /* =================================================
       DASHBOARD
    ================================================= */

    return (

        <main className="dashboard-page">

            <div className="dashboard-container">


                {/* HEADER */}

                <div className="dashboard-header">

                    <span className="dashboard-label">
                        FINTRACK
                    </span>


                    <h1>
                        Your Dashboard
                    </h1>


                    <p>

                        Welcome back,{" "}

                        {
                            localStorage.getItem(
                                "fullName"
                            ) || "User"
                        }.

                    </p>

                </div>


                {/* SUMMARY */}

                <div className="dashboard-summary-grid">


                    {/* INCOME */}

                    <div className="dashboard-summary-card">

                        <span className="summary-card-label">
                            Total Income
                        </span>


                        <h2>

                            ₹{" "}

                            {Number(
                                dashboard?.totalIncome || 0
                            ).toLocaleString(
                                "en-IN",
                                {
                                    minimumFractionDigits: 2,
                                    maximumFractionDigits: 2
                                }
                            )}

                        </h2>

                    </div>


                    {/* EXPENSE */}

                    <div className="dashboard-summary-card">

                        <span className="summary-card-label">
                            Total Expense
                        </span>


                        <h2>

                            ₹{" "}

                            {Number(
                                dashboard?.totalExpense || 0
                            ).toLocaleString(
                                "en-IN",
                                {
                                    minimumFractionDigits: 2,
                                    maximumFractionDigits: 2
                                }
                            )}

                        </h2>

                    </div>


                    {/* BALANCE */}

                    <div className="dashboard-summary-card">

                        <span className="summary-card-label">
                            Balance
                        </span>


                        <h2>

                            ₹{" "}

                            {Number(
                                dashboard?.balance || 0
                            ).toLocaleString(
                                "en-IN",
                                {
                                    minimumFractionDigits: 2,
                                    maximumFractionDigits: 2
                                }
                            )}

                        </h2>

                    </div>


                    {/* BUDGET */}

                    <div className="dashboard-summary-card">

                        <span className="summary-card-label">
                            Total Budget
                        </span>


                        <h2>

                            ₹{" "}

                            {Number(
                                dashboard?.totalBudget || 0
                            ).toLocaleString(
                                "en-IN",
                                {
                                    minimumFractionDigits: 2,
                                    maximumFractionDigits: 2
                                }
                            )}

                        </h2>

                    </div>

                </div>


                {/* QUICK ACTIONS */}

                <div className="dashboard-section">

                    <div className="dashboard-section-header">

                        <h2>
                            Financial Management
                        </h2>


                        <p>
                            Manage your income, expenses,
                            budgets and categories.
                        </p>

                    </div>


                    <div className="dashboard-action-grid">


                        <a
                            href="/income"
                            className="dashboard-action-card"
                        >

                            <div className="dashboard-action-icon">
                                ₹
                            </div>

                            <h3>
                                Income
                            </h3>

                            <p>
                                Add and manage your income.
                            </p>

                        </a>


                        <a
                            href="/expenses"
                            className="dashboard-action-card"
                        >

                            <div className="dashboard-action-icon">
                                ₹
                            </div>

                            <h3>
                                Expenses
                            </h3>

                            <p>
                                Track and manage your expenses.
                            </p>

                        </a>


                        <a
                            href="/budgets"
                            className="dashboard-action-card"
                        >

                            <div className="dashboard-action-icon">
                                ₹
                            </div>

                            <h3>
                                Budgets
                            </h3>

                            <p>
                                Create and manage your budgets.
                            </p>

                        </a>


                        <a
                            href="/categories"
                            className="dashboard-action-card"
                        >

                            <div className="dashboard-action-icon">
                                #
                            </div>

                            <h3>
                                Categories
                            </h3>

                            <p>
                                Manage income and expense categories.
                            </p>

                        </a>

                    </div>

                </div>

            </div>

        </main>
    );
};


export default Dashboard;