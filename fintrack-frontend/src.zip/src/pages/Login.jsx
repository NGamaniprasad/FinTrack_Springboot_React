import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";

import { loginUser } from "../services/api";

const Login = () => {

    const navigate = useNavigate();

    const [email, setEmail] = useState("");
    const [password, setPassword] = useState("");

    const [error, setError] = useState("");
    const [loading, setLoading] = useState(false);


    /* =================================================
       LOGIN
    ================================================= */

    const handleSubmit = async (e) => {

        e.preventDefault();

        setError("");
        setLoading(true);


        try {

            const response = await loginUser({
                email,
                password
            });


            console.log(
                "LOGIN RESPONSE:",
                response
            );


            /* =========================================
               TOKEN CHECK
            ========================================== */

            if (
                !response ||
                !response.token
            ) {

                throw new Error(
                    "Login successful but authentication token was not received."
                );
            }


            /* =========================================
               ROLE
            ========================================== */

            const role = String(
                response.role || ""
            )
                .trim()
                .toUpperCase()
                .replace("ROLE_", "");


            console.log(
                "LOGIN ROLE:",
                role
            );


            /* =========================================
               SAVE AUTH DATA
            ========================================== */

            localStorage.setItem(
                "token",
                response.token
            );

            localStorage.setItem(
                "id",
                response.id ?? ""
            );

            localStorage.setItem(
                "fullName",
                response.fullName ?? ""
            );

            localStorage.setItem(
                "email",
                response.email ?? email
            );

            localStorage.setItem(
                "role",
                role
            );


            console.log(
                "TOKEN:",
                localStorage.getItem("token")
            );

            console.log(
                "ROLE:",
                localStorage.getItem("role")
            );


            /* =========================================
               USER
            ========================================== */

            if (role === "USER") {

                navigate(
                    "/dashboard",
                    {
                        replace: true
                    }
                );

                return;
            }


            /* =========================================
               ADMIN
            ========================================== */

            if (role === "ADMIN") {

                navigate(
                    "/admin/dashboard",
                    {
                        replace: true
                    }
                );

                return;
            }


            /* =========================================
               INVALID ROLE
            ========================================== */

            localStorage.clear();

            throw new Error(
                `Invalid role received: ${response.role}`
            );

        } catch (err) {

            console.error(
                "LOGIN ERROR:",
                err
            );

            setError(
                err.message ||
                "Invalid email or password"
            );

        } finally {

            setLoading(false);
        }
    };


    return (

        <main>

            <h1>
                Login
            </h1>


            {error && (
                <p>
                    {error}
                </p>
            )}


            <form onSubmit={handleSubmit}>

                <input
                    type="email"
                    placeholder="Email"
                    value={email}
                    onChange={(e) =>
                        setEmail(e.target.value)
                    }
                    required
                />


                <input
                    type="password"
                    placeholder="Password"
                    value={password}
                    onChange={(e) =>
                        setPassword(e.target.value)
                    }
                    required
                />


                <button
                    type="submit"
                    disabled={loading}
                >

                    {loading
                        ? "Logging in..."
                        : "Login"
                    }

                </button>

            </form>


            <p>

                Don't have an account?

                {" "}

                <Link to="/register">
                    Register
                </Link>

            </p>

        </main>
    );
};

export default Login;