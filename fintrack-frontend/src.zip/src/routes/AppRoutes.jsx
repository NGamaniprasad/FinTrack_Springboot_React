import {
    BrowserRouter,
    Routes,
    Route,
    Navigate
} from "react-router-dom";

import Home from "../pages/Home";
import About from "../pages/About";
import Contact from "../pages/Contact";
import TermsOfUse from "../pages/TermsOfUse";
import PrivacyPolicy from "../pages/PrivacyPolicy";

import Login from "../pages/Login";
import Register from "../pages/Register";
import AdminLogin from "../pages/AdminLogin";

import Dashboard from "../pages/Dashboard";
import AdminDashboard from "../pages/AdminDashboard";

import Navbar from "../components/Navbar";
import Footer from "../components/Footer";
import CookieBanner from "../components/CookieBanner";

import ProtectedRoute from "../components/ProtectedRoute";


function AppRoutes() {

    return (

        <BrowserRouter>

            <Navbar />

            <Routes>

                {/* =========================
                    HOME
                ========================= */}

                <Route
                    path="/"
                    element={<Home />}
                />


                {/* =========================
                    PUBLIC PAGES
                ========================= */}

                <Route
                    path="/about"
                    element={<About />}
                />

                <Route
                    path="/contact"
                    element={<Contact />}
                />

                <Route
                    path="/terms"
                    element={<TermsOfUse />}
                />

                <Route
                    path="/privacy"
                    element={<PrivacyPolicy />}
                />


                {/* =========================
                    USER AUTH
                ========================= */}

                <Route
                    path="/login"
                    element={<Login />}
                />

                <Route
                    path="/register"
                    element={<Register />}
                />


                {/* =========================
                    ADMIN LOGIN
                ========================= */}

                <Route
                    path="/admin/login"
                    element={<AdminLogin />}
                />


                {/* =========================
                    USER PROTECTED ROUTES
                ========================= */}

                <Route
                    element={
                        <ProtectedRoute role="USER" />
                    }
                >

                    <Route
                        path="/dashboard"
                        element={<Dashboard />}
                    />

                    {/* Add these later */}

                    <Route
                        path="/income"
                        element={<div>Income Page</div>}
                    />

                    <Route
                        path="/expenses"
                        element={<div>Expenses Page</div>}
                    />

                    <Route
                        path="/budgets"
                        element={<div>Budgets Page</div>}
                    />

                    <Route
                        path="/categories"
                        element={<div>Categories Page</div>}
                    />

                </Route>


                {/* =========================
                    ADMIN PROTECTED ROUTES
                ========================= */}

                <Route
                    element={
                        <ProtectedRoute role="ADMIN" />
                    }
                >

                    <Route
                        path="/admin/dashboard"
                        element={<AdminDashboard />}
                    />

                </Route>


                {/* =========================
                    UNKNOWN URL
                ========================= */}

                <Route
                    path="*"
                    element={
                        <Navigate
                            to="/"
                            replace
                        />
                    }
                />

            </Routes>


            <Footer />

            <CookieBanner />

        </BrowserRouter>
    );
}

export default AppRoutes;