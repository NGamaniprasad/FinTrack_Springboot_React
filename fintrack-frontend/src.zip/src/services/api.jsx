
///
const API_BASE_URL =
    "http://localhost:8080/api";


/* =====================================================
   COMMON REQUEST
===================================================== */

const request = async (
    url,
    options = {}
) => {

    const response = await fetch(
        `${API_BASE_URL}${url}`,
        {
            ...options,

            headers: {
                "Content-Type": "application/json",
                ...(options.headers || {})
            }
        }
    );


    const text =
        await response.text();


    let data = {};


    try {

        data = text
            ? JSON.parse(text)
            : {};

    } catch {

        data = {
            message: text
        };
    }


    if (!response.ok) {

        throw new Error(
            data.message ||
            data.error ||
            `Request failed: ${response.status}`
        );
    }


    return data;
};


/* =====================================================
   AUTHENTICATED REQUEST
===================================================== */

const authRequest = async (
    url,
    options = {}
) => {

    const token =
        localStorage.getItem("token");


    if (!token) {

        throw new Error(
            "Authentication token not found"
        );
    }


    return request(
        url,
        {
            ...options,

            headers: {

                Authorization:
                    `Bearer ${token}`,

                ...(options.headers || {})
            }
        }
    );
};


/* =====================================================
   AUTHENTICATION
===================================================== */


/* REGISTER */

export const registerUser =
    async (userData) => {

        return request(
            "/auth/register",
            {
                method: "POST",

                body:
                    JSON.stringify(userData)
            }
        );
    };


/* USER LOGIN */

export const loginUser =
    async (loginData) => {

        return request(
            "/auth/login",
            {
                method: "POST",

                body:
                    JSON.stringify(loginData)
            }
        );
    };


/* ADMIN LOGIN */

export const loginAdmin =
    async (loginData) => {

        return request(
            "/auth/admin/login",
            {
                method: "POST",

                body:
                    JSON.stringify(loginData)
            }
        );
    };


/* =====================================================
   USER PROFILE
===================================================== */

export const getProfile =
    async () => {

        return authRequest(
            "/users/profile",
            {
                method: "GET"
            }
        );
    };


/* =====================================================
   USER DASHBOARD
===================================================== */

export const getDashboard =
    async () => {

        return authRequest(
            "/dashboard",
            {
                method: "GET"
            }
        );
    };


/* =====================================================
   CATEGORIES
===================================================== */

export const getCategories =
    async () => {

        return authRequest(
            "/categories",
            {
                method: "GET"
            }
        );
    };


export const addCategory =
    async (categoryData) => {

        return authRequest(
            "/categories",
            {
                method: "POST",

                body:
                    JSON.stringify(categoryData)
            }
        );
    };


export const updateCategory =
    async (
        id,
        categoryData
    ) => {

        return authRequest(
            `/categories/${id}`,
            {
                method: "PUT",

                body:
                    JSON.stringify(categoryData)
            }
        );
    };


export const deleteCategory =
    async (id) => {

        return authRequest(
            `/categories/${id}`,
            {
                method: "DELETE"
            }
        );
    };


/* =====================================================
   INCOME
===================================================== */

export const getIncomes =
    async () => {

        return authRequest(
            "/incomes",
            {
                method: "GET"
            }
        );
    };


export const addIncome =
    async (incomeData) => {

        return authRequest(
            "/incomes",
            {
                method: "POST",

                body:
                    JSON.stringify(incomeData)
            }
        );
    };


export const updateIncome =
    async (
        id,
        incomeData
    ) => {

        return authRequest(
            `/incomes/${id}`,
            {
                method: "PUT",

                body:
                    JSON.stringify(incomeData)
            }
        );
    };


export const deleteIncome =
    async (id) => {

        return authRequest(
            `/incomes/${id}`,
            {
                method: "DELETE"
            }
        );
    };


/* =====================================================
   EXPENSE
===================================================== */

export const getExpenses =
    async () => {

        return authRequest(
            "/expenses",
            {
                method: "GET"
            }
        );
    };


export const addExpense =
    async (expenseData) => {

        return authRequest(
            "/expenses",
            {
                method: "POST",

                body:
                    JSON.stringify(expenseData)
            }
        );
    };


export const updateExpense =
    async (
        id,
        expenseData
    ) => {

        return authRequest(
            `/expenses/${id}`,
            {
                method: "PUT",

                body:
                    JSON.stringify(expenseData)
            }
        );
    };


export const deleteExpense =
    async (id) => {

        return authRequest(
            `/expenses/${id}`,
            {
                method: "DELETE"
            }
        );
    };


/* =====================================================
   BUDGET
===================================================== */

export const getBudgets =
    async () => {

        return authRequest(
            "/budgets",
            {
                method: "GET"
            }
        );
    };


export const addBudget =
    async (budgetData) => {

        return authRequest(
            "/budgets",
            {
                method: "POST",

                body:
                    JSON.stringify(budgetData)
            }
        );
    };


export const updateBudget =
    async (
        id,
        budgetData
    ) => {

        return authRequest(
            `/budgets/${id}`,
            {
                method: "PUT",

                body:
                    JSON.stringify(budgetData)
            }
        );
    };
    export const getAdminDashboard = async () => {

    return authRequest(
        "/admin/dashboard",
        {
            method: "GET"
        }
    );
};


export const deleteBudget =
    async (id) => {

        return authRequest(
            `/budgets/${id}`,
            {
                method: "DELETE"
            }
        );
    };