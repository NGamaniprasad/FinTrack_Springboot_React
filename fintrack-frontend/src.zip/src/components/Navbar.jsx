import { Link, useLocation } from "react-router-dom";
import { useState } from "react";

import "./Navbar.css";

function Navbar() {

    const location = useLocation();

    const [menuOpen, setMenuOpen] = useState(false);

    const closeMenu = () => {
        setMenuOpen(false);
    };

    return (
        <header className="navbar">

            <div className="navbar-container">

                {/* LOGO */}

                <Link
                    to="/"
                    className="navbar-logo"
                    onClick={closeMenu}
                >
                    Fin<span>Track</span>
                </Link>


                {/* DESKTOP NAVIGATION */}

                <nav
                    className={
                        menuOpen
                            ? "navbar-nav mobile-open"
                            : "navbar-nav"
                    }
                >

                    <Link
                        to="/"
                        className={
                            location.pathname === "/"
                                ? "nav-link active"
                                : "nav-link"
                        }
                        onClick={closeMenu}
                    >
                        Home
                    </Link>

                    <Link
                        to="/about"
                        className={
                            location.pathname === "/about"
                                ? "nav-link active"
                                : "nav-link"
                        }
                        onClick={closeMenu}
                    >
                        About
                    </Link>

                    <Link
                        to="/contact"
                        className={
                            location.pathname === "/contact"
                                ? "nav-link active"
                                : "nav-link"
                        }
                        onClick={closeMenu}
                    >
                        Contact
                    </Link>

                    <div className="mobile-auth-links">

                        <Link
                            to="/login"
                            onClick={closeMenu}
                        >
                            Login
                        </Link>

                        <Link
                            to="/register"
                            onClick={closeMenu}
                        >
                            Register
                        </Link>

                    </div>

                </nav>


                {/* DESKTOP AUTH */}

                <div className="navbar-actions">

                    <Link
                        to="/login"
                        className="nav-login"
                    >
                        Login
                    </Link>

                    <Link
                        to="/register"
                        className="nav-register"
                    >
                        Register
                    </Link>
                    <Link
        to="/admin/login"
        className="nav-admin-login"
    >
        Admin Login
    </Link>

                </div>


                {/* MOBILE MENU */}

                <button
                    className="menu-button"
                    onClick={() => setMenuOpen(!menuOpen)}
                    aria-label="Toggle menu"
                >
                    ☰
                </button>

            </div>

        </header>
    );
}

export default Navbar;