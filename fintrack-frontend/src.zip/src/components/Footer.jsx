import { Link } from "react-router-dom";

import "./Footer.css";

function Footer() {

    return (
        <footer className="footer">

            <div className="footer-container">

                <div className="footer-brand">

                    <Link
                        to="/"
                        className="footer-logo"
                    >
                        Fin<span>Track</span>
                    </Link>

                    <p>
                        Smart financial tools designed to make
                        everyday financial decisions easier.
                    </p>

                </div>


                <div className="footer-column">

                    <h3>Company</h3>

                    <Link to="/">
                        Home
                    </Link>

                    <Link to="/about">
                        About Us
                    </Link>

                    <Link to="/contact">
                        Contact
                    </Link>

                </div>


                <div className="footer-column">

                    <h3>Legal</h3>

                    <Link to="/terms">
                        Terms of Use
                    </Link>

                    <Link to="/privacy">
                        Privacy Policy
                    </Link>

                </div>


                <div className="footer-column">

                    <h3>Account</h3>

                    <Link to="/login">
                        User Login
                    </Link>

                    <Link to="/register">
                        Create Account
                    </Link>

                    <Link to="/admin/login">
                        Admin Login
                    </Link>

                </div>

            </div>


            <div className="footer-bottom">

                <p>
                    © {new Date().getFullYear()} FinTrack.
                    All rights reserved.
                </p>

            </div>

        </footer>
    );
}

export default Footer;