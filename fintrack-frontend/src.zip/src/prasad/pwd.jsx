// {
//   "fullName": "Test User",
//   "email": "test@gmail.com",
//   "password": "123456",
//   "confirmPassword": "123456"
// }

// {
    
//     "email": "test1@gmail.com",
//     "password": "123456"
    
// }

// {
//     "fullName": "FinTrack Admin",
//     "email": "admin@fintrack.com",
//     "password": "Admin@123"
// }